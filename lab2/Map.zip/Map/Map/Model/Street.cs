﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Map
{
    public class Street
    {
        public string Name { get; set; }
        public List<House> ListHouses { get; set; }

    }
}