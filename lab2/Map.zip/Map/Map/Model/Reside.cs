﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Map.Model
{
    public class Reside
    {
        public Flat Flat { get; set; }
        public Resident Resident { get; set; }

        public Reside()
        {
        }
    }
}